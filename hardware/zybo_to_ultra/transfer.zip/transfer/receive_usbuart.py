import usb.core
import usb.util
import sys

# Identify the USB device
VID = 0x0403  # Replace with the vendor ID
PID = 0x6001  # Replace with the product ID

dev = usb.core.find(idVendor=VID, idProduct=PID)

if dev is None:
    raise ValueError('Périphérique USB non trouvé')

if dev.is_kernel_driver_active(0):
    dev.detach_kernel_driver(0)

# Configure the device
dev.set_configuration()
cfg = dev.get_active_configuration()
intf = cfg[(0, 0)]

# Find the IN endpoint
ep = usb.util.find_descriptor(
    intf,
    # Match the first IN endpoint
    custom_match=lambda e: usb.util.endpoint_direction(e.bEndpointAddress) == usb.util.ENDPOINT_IN)

assert ep is not None

# File to save the received data
filename = 'received_audio.txt'

# Open the file in write-binary mode
with open(filename, 'wb') as f:
    try:
        while True:
            try:
                # Read data from the IN endpoint
                data = dev.read(ep.bEndpointAddress, ep.wMaxPacketSize)
                f.write(data)
            except usb.core.USBError as e:
                if e.args == ('Operation timed out',):
                    continue
                raise
    except KeyboardInterrupt:
        print("Data reception interrupted")
    finally:
        usb.util.dispose_resources(dev)

print(f"Data saved to {filename}")
